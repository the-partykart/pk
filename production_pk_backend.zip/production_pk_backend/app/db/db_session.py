import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from config.config import settings
from app.db.models.db_base import Base
from contextlib import asynccontextmanager



db_name = settings.db_name
db_drivername = settings.db_drivername
db_username = settings.db_username
db_password = settings.db_password
db_port = settings.db_port
db_database_name = settings.db_database_name
db_server = settings.db_server
DB_url = f"{db_name}+{db_drivername}://{db_username}:{db_password}@{db_server}:{db_port}/{db_database_name}"

async_engine = create_async_engine(DB_url, echo=False) 
async_session_maker = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False )

async def get_async_session() -> AsyncSession:
    """
    Dependency to get an asynchronous database session.
    It creates a new session for each request and closes it after t he request.
    """
    async with async_session_maker() as session:
        yield session


@asynccontextmanager
async def get_async_session_context():
    async with async_session_maker() as session:
        yield session