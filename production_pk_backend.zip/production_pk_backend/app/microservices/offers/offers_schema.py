from pydantic import BaseModel
from typing import Optional

class Createoffer(BaseModel):
    offer_name : str
    offer_percentage : int
    offer_description : Optional[str] = "No information available for this offer"

class Updateoffer(BaseModel):
    offer_name : Optional[str] = None
    offer_percentage : Optional[int] = None
    offer_description : Optional[str] = "No information available for this offer"