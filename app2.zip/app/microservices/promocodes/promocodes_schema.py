from pydantic import BaseModel
from typing import Optional

class CreatePromocode(BaseModel):
    promocode_percentage : int
    promocode_description : Optional[str] = "No information available for this promocode"
    promocode_name : str

class UpdatePromocode(BaseModel):
    promocode_name : Optional[str] = None
    promocode_percentage : Optional[int] = None
    promocode_description : Optional[str] = "No information available for this promocode"